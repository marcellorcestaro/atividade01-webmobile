//: # ASCII ART
//      ___   _____ ______________   ___    ____  ______
//    /   | / ___// ____/  _/  _/  /   |  / __ \/_  __/
//   / /| | \__ \/ /    / / / /   / /| | / /_/ / / /
//  / ___ |___/ / /____/ /_/ /   / ___ |/ _, _/ / /
// /_/  |_/____/\____/___/___/  /_/  |_/_/ |_| /_/

import UIKit
//: 1. Busca a imagem na pasta Resources pelo nome
let imagepng = UIImage(named: "logo_red")
//: 2. Cria uma variável do tipo Image (criado para este playground e disponível na pasta Sources)
var img = Image(imagepng!)
//: 3. dimensões da imagem
let w = img.width
let h = img.height
//: 4. Array de pixels.
let pixels = img.pixels
//: _Pixel é uma estrutura criada para este playground e possui os atributos red, green, blue e alpha. Para o valor de vermelho do primeiro pixel, por exemplo, use:_
//:
//: `pixels[0].red`
//:
//: *Agora é com você!*
//:
//: _use imagens de tamanhos pequenos, ou seu código pode demorar para rodar. 50x50 funciona legal!_

var count_to_width = 0;

print(pixels[0].red)

for pixel in pixels {
    let media = (Int(pixel.red) + Int(pixel.blue) + Int(pixel.green)) / 3
    
    count_to_width += 1;
    
    if media <= 64 {
        print("%", terminator: "")
    } else if media > 64 && media <= 128 {
        print("&", terminator: "")
    } else if media > 128 && media <= 192 {
        print("/", terminator: "")
    } else if media > 192 && media <= 240 {
        print("@", terminator: "")
    } else {
        print(" ", terminator: "")
    }
    
    if count_to_width >= w {
        count_to_width = 0
        print("\n", terminator: "")
    }
    
}
